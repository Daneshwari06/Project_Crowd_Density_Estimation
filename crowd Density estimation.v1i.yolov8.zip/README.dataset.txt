# crowd Density estimation > 2025-04-23 2:43pm
https://universe.roboflow.com/ddp-jtw2a/crowd-density-estimation-pjv5l

Provided by a Roboflow user
License: CC BY 4.0

